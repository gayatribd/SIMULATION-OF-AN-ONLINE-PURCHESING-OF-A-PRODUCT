package com.example.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Servlet implementation class PaymentServlet
 */
@WebServlet("/PaymentServlet")
public class PaymentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PaymentServlet() {
        super();

    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		HttpSession sess=request.getSession();
		
		
		RequestDispatcher rd;
				
		//payment details collection
        if (request.getParameter("place_order") != null) {
            System.out.println("into place order!!");
            //get credit card information
            String card_type = (String) request.getParameter("card_type");
            String card_name = request.getParameter("card_name");
            String expiration_month = (String) request.getParameter("expiration_month");
            String expiration_year = (String) request.getParameter("expiration_year");


            //get billing information
            String fullname = request.getParameter("fullname");
            String address = request.getParameter("address");
            String country = request.getParameter("country");
            String zipcode = request.getParameter("zipcode");
            sess.setAttribute("Order_Confirmation", "Confirmed");
            String Confirmation_Status = (String) sess.getAttribute("Order_Confirmation");
            System.out.println("Confirmation_Status = " + Confirmation_Status); //setting the order status as confirmed as no errors so far..
            
            DomParsing.card_n_shipping_info(card_type, card_name, expiration_month, expiration_year, fullname, address, country, zipcode);
            
            rd = request.getRequestDispatcher("/payment.jsp");
            rd.forward(request, response);
        } //payment and billing information ends here
		
		
	}

}
